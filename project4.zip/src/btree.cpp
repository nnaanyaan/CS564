/**
 * @author See Contributors.txt for code contributors and overview of BadgerDB.
 *
 * @section LICENSE
 * Copyright (c) 2012 Database Group, Computer Sciences Department, University of Wisconsin-Madison.
 */

#include "btree.h"
#include "filescan.h"
#include "exceptions/bad_index_info_exception.h"
#include "exceptions/bad_opcodes_exception.h"
#include "exceptions/bad_scanrange_exception.h"
#include "exceptions/no_such_key_found_exception.h"
#include "exceptions/scan_not_initialized_exception.h"
#include "exceptions/index_scan_completed_exception.h"
#include "exceptions/file_not_found_exception.h"
#include "exceptions/end_of_file_exception.h"

#include <sstream>
#include <string>
#include <cstring>
#include "exceptions/page_pinned_exception.h"
#include "exceptions/page_not_pinned_exception.h"

//#define DEBUG

namespace badgerdb {

// -----------------------------------------------------------------------------
// BTreeIndex::BTreeIndex -- Constructor
// -----------------------------------------------------------------------------
 /**
   * BTreeIndex Constructor. 
	 * Check to see if the corresponding index file exists. If so, open the file.
	 * If not, create it and insert entries for every tuple in the base relation using FileScan class.
   *
   * @param relationName        Name of file.
   * @param outIndexName        Return the name of index file.
   * @param bufMgrIn						Buffer Manager Instance
   * @param attrByteOffset			Offset of attribute, over which index is to be built, in the record
   * @param attrType						Datatype of attribute over which index is built
   * @throws  BadIndexInfoException     If the index file already exists for the corresponding attribute, but values in metapage(relationName, attribute byte offset, attribute type etc.) do not match with values received through constructor parameters.
   */
BTreeIndex::BTreeIndex(const std::string & relationName,
		std::string & outIndexName, BufMgr *bufMgrIn, const int attrByteOffset,
		const Datatype attrType) {
	// Constructing an index file name
	std::ostringstream idxStr;
	idxStr << relationName << '.' << attrByteOffset;
	outIndexName = idxStr.str();
	// Cast bufMgr to the glocal buffer manager
	bufMgr = bufMgrIn;
	// Declare the header page
	Page* headerPage;
	// If the index file exists, the file is opened.
	try {
		file = new BlobFile(outIndexName, false);
		// Read header page into buffer pool and compare if values in metapage
		// match values received through constructor parameters
		bufMgr->readPage(file, 1, headerPage);
		// Cast headerPage into IndexMetaInfo to retrieve info
		IndexMetaInfo* indexMetaInfo =
				reinterpret_cast<IndexMetaInfo*>(headerPage);
		// Unpin header headerPage since it is not required
		bufMgr->unPinPage(file, 1, false);
		// If not match, throw BadIndexInfoException
		if (relationName != indexMetaInfo->relationName
				|| attrByteOffset != indexMetaInfo->attrByteOffset
				|| attrType != indexMetaInfo->attrType) {
			throw BadIndexInfoException(outIndexName);
		}
	}
	// If the index file doesn't exist, creating a new one.
	catch (FileNotFoundException e) {
		file = new BlobFile(outIndexName, true);
		// Initialize some basic declared private variables
		attributeType = attrType;
		this->attrByteOffset = attrByteOffset;
		scanExecuting = false;
		// Build the header page
		bufMgr->allocPage(file, headerPageNum, headerPage);
		IndexMetaInfo* indexMetaInfo =
				reinterpret_cast<IndexMetaInfo*>(headerPage);
		strcpy(indexMetaInfo->relationName, relationName.c_str());
		indexMetaInfo->attrByteOffset = attrByteOffset;
		indexMetaInfo->attrType = attrType;
		// Build the root page
		Page* rootPage;
		bufMgr->allocPage(file, rootPageNum, rootPage);
		indexMetaInfo->rootPageNo = rootPageNum;
		// Unpin header page after building
		bufMgr->unPinPage(file, headerPageNum, true);
		// setting the info for root page
		// And initialize leafOccupancy and nodeOccupancy
		NonLeafNodeInt* node = reinterpret_cast<NonLeafNodeInt*>(rootPage);
		node->level = 1;
		leafOccupancy = INTARRAYLEAFSIZE;
		nodeOccupancy = INTARRAYNONLEAFSIZE;
		for (int i = 0; i < nodeOccupancy + 1; i++) {
			node->pageNoArray[i] = Page::INVALID_NUMBER;
		}
		
	
		// Unpin root page after building
		bufMgr->unPinPage(file, rootPageNum, true);
		// Scan the relation file and insert records into the B+ tree
		try {
			FileScan fscan(relationName, bufMgr);
			RecordId scanRid;
			while (1) {
				fscan.scanNext(scanRid);
				std::string recordStr = fscan.getRecord();
				const char* record = recordStr.c_str();
				void* key = (void*) (record + attrByteOffset);
				insertEntry(key, scanRid);
			}
		} catch (EndOfFileException e) {
		}
	}
}

// -----------------------------------------------------------------------------
// BTreeIndex::~BTreeIndex -- destructor
// -----------------------------------------------------------------------------
 /**
   * BTreeIndex Destructor. 
	 * End any initialized scan, flush index file, after unpinning any pinned pages, from the buffer manager
	 * and delete file instance thereby closing the index file.
	 * Destructor should not throw any exceptions. All exceptions should be caught in here itself. 
	 * */
BTreeIndex::~BTreeIndex() {
	if (scanExecuting) {
		try {
		endScan();
	}
	catch(ScanNotInitializedException e) {
}
}
	if (file) {
	bufMgr->flushFile(file);
}
	delete file;
}

// -----------------------------------------------------------------------------
// BTreeIndex::insertEntry
// -----------------------------------------------------------------------------
/**
	 * Insert a new entry using the pair <value,rid>. 
	 * Start from root to recursively find out the leaf to insert the entry in. The insertion may cause splitting of leaf node.
	 * This splitting will require addition of new leaf page number entry into the parent non-leaf, which may in-turn get split.
	 * This may continue all the way upto the root causing the root to get split. If root gets split, metapage needs to be changed accordingly.
	 * Make sure to unpin pages as soon as you can.
   * @param key			Key to insert, pointer to integer/double/char string
   * @param rid			Record ID of a record whose entry is getting inserted into the index.
	**/
const void BTreeIndex::insertEntry(const void *key, const RecordId rid) {
	// read root page
	Page* rootPage;
	bufMgr->readPage(file, rootPageNum, rootPage);
	PageKeyPair <int> newChildEntryInt;
	insertRecursively((int*) key, rid,
			rootPage, false, true, newChildEntryInt);
	
	// in case root page is not pinned
	try {
		bufMgr->unPinPage(file, rootPageNum, true);
	} catch (PageNotPinnedException e) {
	}
}

// -----------------------------------------------------------------------------
// BTreeIndex::startScan
// -----------------------------------------------------------------------------
/**
	 * Begin a filtered scan of the index.  For instance, if the method is called 
	 * using (1,GT,100,LTE) then we should seek all entries with a value 
	 * greater than "1" and less than or equal to "100".
	 * If another scan is already executing, that needs to be ended here.
	 * Set up all the variables for scan. Start from root to find out the leaf page that contains the first RecordID
	 * that satisfies the scan parameters. Keep that page pinned in the buffer pool.
   * @param lowVal	Low value of range, pointer to integer 
   * @param lowOp		Low operator (GT/GTE)
   * @param highVal	High value of range, pointer to integer 
   * @param highOp	High operator (LT/LTE)
   * @throws  BadOpcodesException If lowOp and highOp do not contain one of their their expected values 
   * @throws  BadScanrangeException If lowVal > highval
	 * @throws  NoSuchKeyFoundException If there is no key in the B+ tree that satisfies the scan criteria.
	**/
const void BTreeIndex::startScan(const void* lowValParm,
		const Operator lowOpParm, const void* highValParm,
		const Operator highOpParm) {
	// check to make sure the op values are used the correct way for ranges
	if ((lowOpParm != GT && lowOpParm != GTE)
			|| (highOpParm != LT && highOpParm != LTE)) {
		throw BadOpcodesException();
	}
	// If lowValue > highValue, throw the exception BadScanrangeException
	if (keyCompare(lowValParm, highValParm) > 0) {
		throw BadScanrangeException();
	}
	// Set scan status
	scanExecuting = true;
	// If there is no exception due to bad inputs, initialize ops and scan range
	lowOp = lowOpParm;
	highOp = highOpParm;
	lowValInt = *((int*) lowValParm);
	highValInt = *((int*) highValParm);
	startScanTemplate(&lowValInt, lowOp,
			&highValInt, highOp);
	
}

// -----------------------------------------------------------------------------
// BTreeIndex::scanNext
// -----------------------------------------------------------------------------
/**
	 * Fetch the record id of the next index entry that matches the scan.
	 * Return the next record from current page being scanned. If current page has been scanned to its entirety, move on to the right sibling of current page, if any exists, to start scanning that page. Make sure to unpin any pages that are no longer required.
   * @param outRid	RecordId of next record found that satisfies the scan criteria returned in this
	 * @throws ScanNotInitializedException If no scan has been initialized.
	 * @throws IndexScanCompletedException If no more records, satisfying the scan criteria, are left to be scanned.
	**/
const void BTreeIndex::scanNext(RecordId& outRid) {
	//check to make sure a scan is in progress
	if (!scanExecuting)
		throw ScanNotInitializedException();
	//to check if the scan is over
	if (nextEntry == -1) {
		throw IndexScanCompletedException();
	}
	// call scanNextTemplate
	scanNextTemplate(outRid, &highValInt);
}

// -----------------------------------------------------------------------------
// BTreeIndex::endScan
// -----------------------------------------------------------------------------
 /**
	 * Terminate the current scan. Unpin any pinned pages. Reset scan specific variables.
	 * @throws ScanNotInitializedException If no scan has been initialized.
	**/
const void BTreeIndex::endScan() {
	//check to make sure there is a scan running 
	if (!scanExecuting) {
		throw ScanNotInitializedException();
	}
	// Unpin current page
	bufMgr->unPinPage(file, currentPageNum, false);
	// Clear up the necessary state variables
	scanExecuting = false;
	nextEntry = -1;
	currentPageNum = Page::INVALID_NUMBER;
	currentPageData = NULL;
}
// Private member methods
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// BTreeIndex::keyCompare
// -----------------------------------------------------------------------------

const int BTreeIndex::keyCompare(const void* key1, const void* key2) {
	int* newKey1Int = (int*) key1;
	int* newKey2Int = (int*) key2;
	if (*newKey1Int > *newKey2Int)
		return 1;
	else if (*newKey1Int < *newKey2Int)
		return -1;
	else
		return 0;
}

// -----------------------------------------------------------------------------
// BTreeIndex::keyCopy
// -----------------------------------------------------------------------------

const void BTreeIndex::keyCopy(const void* key1, const void* key2) {
	int* newKey1Int = (int*) key1;
	int* newKey2Int = (int*) key2;
	*newKey1Int = *newKey2Int;
}

// -----------------------------------------------------------------------------
// BTreeIndex::insertRecursively
// -----------------------------------------------------------------------------

const void BTreeIndex::insertRecursively(const int* key, const RecordId rid,
		Page* page, bool isLeaf, bool isRoot,
		PageKeyPair<int> &newChildEntry) {
	// Insertion index
	int insertIndex;
	// If current node is a non-leaf node
	if (!isLeaf) {
		// Transform current node to nonLeafNodeType
		NonLeafNodeInt* nonLeafNode = (NonLeafNodeInt*) page;
		// Find appropriate position in pageNoArray.
		insertIndex = -1;
		// No key in array or key in entry is less than the first key in array.
		if (nonLeafNode->pageNoArray[0] == Page::INVALID_NUMBER
				|| keyCompare(key, &(nonLeafNode->keyArray[0])) < 0) {
			insertIndex = 0;
		} else {
			for (int i = 0; i < nodeOccupancy; i++) {
				// Find a blank position
				if (nonLeafNode->pageNoArray[i + 1] == Page::INVALID_NUMBER) {
					insertIndex = i;
					break;
				}
				//  key in entry is larger than any key in array
				//  or find an appropriate position between keys in array.
				if (keyCompare(key, &(nonLeafNode->keyArray[i])) >= 0) {
					if (i == (nodeOccupancy - 1)
							|| nonLeafNode->pageNoArray[i + 2]
									== Page::INVALID_NUMBER
							|| keyCompare(key, &(nonLeafNode->keyArray[i + 1]))
									< 0) {
						insertIndex = i + 1;
						break;
					}
				}
			}
		}
		// Check if next level is leaf node.
		if (nonLeafNode->level == 1)
			isLeaf = true;
		else
			isLeaf = false;
		// get the appropriate child page
		PageId childPageNo = nonLeafNode->pageNoArray[insertIndex];
		Page* childPage = NULL;
		// if child page is invalid, nuild a new one
		if (childPageNo == Page::INVALID_NUMBER) {
			bufMgr->allocPage(file, childPageNo, childPage);
			nonLeafNode->pageNoArray[insertIndex] = childPageNo;
			if (isLeaf) {
				LeafNodeInt* childLeaf = (LeafNodeInt*) childPage;
				for (int j = 0; j < leafOccupancy; j++) {
					childLeaf->ridArray[j].page_number = Page::INVALID_NUMBER;
				}
				childLeaf->rightSibPageNo = Page::INVALID_NUMBER;
			} else {
				NonLeafNodeInt* childNode = (NonLeafNodeInt*) childPage;
				for (int k = 0; k < nodeOccupancy + 1; k++) {
					childNode->pageNoArray[k] = Page::INVALID_NUMBER;
				}
				childNode->level = nonLeafNode->level - 1;
			}
		}
		// If child page is valid, read the page.
		else {
			bufMgr->readPage(file, childPageNo, childPage);
		}
		insertRecursively(key, rid,
				childPage, isLeaf, false, newChildEntry);
		bufMgr->unPinPage(file, childPageNo, true);
		// usual case; dont's split child.
		if (newChildEntry.pageNo == Page::INVALID_NUMBER) {
			return;
		}
		// split child, insert *newChildEntry in non leaf node.
		else {
			// Find position to insert
			insertIndex = -1;
			// key in entry is less than the first key in array.
			if (nonLeafNode->pageNoArray[0] == Page::INVALID_NUMBER
					|| keyCompare(&(newChildEntry.key),
							&(nonLeafNode->keyArray[0])) < 0) {
				insertIndex = 0;
			} else {
				for (int i = 0; i < nodeOccupancy; i++) {
					// Find a blank position
					if (nonLeafNode->pageNoArray[i + 1]
							== Page::INVALID_NUMBER) {
						insertIndex = i;
						break;
					}
					//  key in entry is larger than any key in array
					//  or find an appropriate position between keys in array.
					if (keyCompare(&(newChildEntry.key),
							&(nonLeafNode->keyArray[i])) >= 0) {
						if (i == (nodeOccupancy - 1)
								|| nonLeafNode->pageNoArray[i + 2]
										== Page::INVALID_NUMBER
								|| keyCompare(&(newChildEntry.key),
										&(nonLeafNode->keyArray[i + 1])) < 0) {
							insertIndex = i + 1;
							break;
						}
					}
				}
			}
			// usual case, nonLeafNode has space
			if (nonLeafNode->pageNoArray[nodeOccupancy]
					== Page::INVALID_NUMBER) {
				// Put *newChildEntry on it, set newChildEntry to null, return
				// Shift keys and pageNos.
				for (int j = nodeOccupancy - 1; j > insertIndex; j--) {
					keyCopy(&(nonLeafNode->keyArray[j]),
							&(nonLeafNode->keyArray[j - 1]));
					nonLeafNode->pageNoArray[j + 1] =
							nonLeafNode->pageNoArray[j];
				}
				// Insert key and pageNo.
				keyCopy(&(nonLeafNode->keyArray[insertIndex]),
						&(newChildEntry.key));
				nonLeafNode->pageNoArray[insertIndex + 1] =
						newChildEntry.pageNo;
				// set newChildEntry to null and return
				newChildEntry.pageNo = Page::INVALID_NUMBER;
				return;
			}
			// split nonLeafNode.
			else {
				// 2d + 1 key values and 2d + 2 nodepointers.
				// first d key values and d + 1 nodepointers stay,
				// last d key values and d + 1 nodepointers move to new node.
				int d = nodeOccupancy / 2;
				// build new node
				PageId newNonLeafPageNo;
				Page* newNonLeafPage;
				bufMgr->allocPage(file, newNonLeafPageNo, newNonLeafPage);
				NonLeafNodeInt* newNonLeafNode =
						(NonLeafNodeInt*) newNonLeafPage;
				newNonLeafNode->level = nonLeafNode->level;
				for (int k = 0; k < nodeOccupancy + 1; k++) {
					newNonLeafNode->pageNoArray[k] = Page::INVALID_NUMBER;
				}
				// move last d keys and d + 1 nodepointers.
				for (int l = d; l < nodeOccupancy; l++) {
					keyCopy(&(newNonLeafNode->keyArray[l - d]),
							&(nonLeafNode->keyArray[l]));
					newNonLeafNode->pageNoArray[l - d + 1] =
							nonLeafNode->pageNoArray[l + 1];
					// Clear the array
					nonLeafNode->pageNoArray[l + 1] = Page::INVALID_NUMBER;
				}
				newNonLeafNode->pageNoArray[0] = nonLeafNode->pageNoArray[d];
				PageId tempPageNo = newChildEntry.pageNo;
				Datatype* tempKey = new Datatype;
				keyCopy(tempKey, &(newChildEntry.key));
				newChildEntry.pageNo = newNonLeafPageNo;
				// insertion position in the first half
				if (insertIndex < d) {
					// push up the key
					keyCopy(&(newChildEntry.key),
							&(nonLeafNode->keyArray[d - 1]));
					// shift keys and page numbers
					for (int m = d - 1; m > insertIndex; m--) {
						keyCopy(&(nonLeafNode->keyArray[m]),
								&(nonLeafNode->keyArray[m - 1]));
						nonLeafNode->pageNoArray[m + 1] =
								nonLeafNode->pageNoArray[m];
					}
					// insert
					keyCopy(&(nonLeafNode->keyArray[insertIndex]), tempKey);
					nonLeafNode->pageNoArray[insertIndex + 1] = tempPageNo;
				}
				// insertion position in the last half
				else if (insertIndex == d) {
					// insert
					newNonLeafNode->pageNoArray[0] = tempPageNo;
				} else {
					// push up the key
					keyCopy(&(newChildEntry.key),
							&(newNonLeafNode->keyArray[0]));
					// shift keys and page numbers
					for (int n = 0; n < insertIndex - d - 1; n++) {
						keyCopy(&(newNonLeafNode->keyArray[n]),
								&(newNonLeafNode->keyArray[n + 1]));
						newNonLeafNode->pageNoArray[n] =
								newNonLeafNode->pageNoArray[n + 1];
					}
					newNonLeafNode->pageNoArray[insertIndex - d - 1] =
							newNonLeafNode->pageNoArray[insertIndex - d];
					// insert
					keyCopy(&(newNonLeafNode->keyArray[insertIndex - d - 1]),
							tempKey);
					newNonLeafNode->pageNoArray[insertIndex - d] = tempPageNo;
				}
				delete tempKey;
				// if root node was just split
				if (isRoot) {
					// Build a new root
					PageId newRootPageNo;
					Page* newRootPage;
					bufMgr->allocPage(file, newRootPageNo, newRootPage);
					// Modify private variables
					PageId oldRootPageNum = rootPageNum;
					rootPageNum = newRootPageNo;
					// Modify header page
					Page* headerPage;
					bufMgr->readPage(file, headerPageNum, headerPage);
					IndexMetaInfo* indexMetaInfo =
							reinterpret_cast<IndexMetaInfo*>(headerPage);
					indexMetaInfo->rootPageNo = newRootPageNo;
					bufMgr->unPinPage(file, headerPageNum, true);
					// continue building root node.
					NonLeafNodeInt* newRootNode =
							(NonLeafNodeInt*) newRootPage;
					newRootNode->level = nonLeafNode->level + 1;
					for (int i = 0; i < nodeOccupancy + 1; i++) {
						newRootNode->pageNoArray[i] = Page::INVALID_NUMBER;
					}
					keyCopy(&(newRootNode->keyArray[0]), &(newChildEntry.key));
					newRootNode->pageNoArray[0] = oldRootPageNum;
					newRootNode->pageNoArray[1] = newNonLeafPageNo;
					// set newChildEntry to null
					//newChildEntry.pageNo = Page::INVALID_NUMBER;
					// unpin newRootPage
					bufMgr->unPinPage(file, newRootPageNo, true);
				}
				// unpin newNonLeafPage
				bufMgr->unPinPage(file, newNonLeafPageNo, true);
				return;
			}
		}
	}
	// If current node is a leaf node
	else {
		// Transform current node to LeafNodeType
		LeafNodeInt* leafNode = (LeafNodeInt*) page;
		// No matter if the leaf node is full, need to find the index to insert
		// Find appropriate index to insert.
		insertIndex = leafOccupancy;
		for (int i = 0; i < leafOccupancy; i++) {
			// First black position or middle position is appropriate.
			if (leafNode->ridArray[i].page_number == Page::INVALID_NUMBER
					|| keyCompare(key, &(leafNode->keyArray[i])) < 0) {
				insertIndex = i;
				break;
			}
		}
		// If leafNode has space
		if (leafNode->ridArray[leafOccupancy - 1].page_number
				== Page::INVALID_NUMBER) {
			// Shift keys and record IDs for insertion.
			for (int j = leafOccupancy - 1; j > insertIndex; j--) {
				keyCopy(&(leafNode->keyArray[j]), &(leafNode->keyArray[j - 1]));
				leafNode->ridArray[j] = leafNode->ridArray[j - 1];
			}
			// Put entry on it, set newChildEntry to null, and return.
			keyCopy(&(leafNode->keyArray[insertIndex]), key);
			leafNode->ridArray[insertIndex] = rid;
			newChildEntry.pageNo = Page::INVALID_NUMBER;
			return;
		}
		// Once in a while, the leaf is full
		else {
			// split leaf node
			// first d entries stay, rest move to brand new node
			int d = leafOccupancy / 2;
			// Build the new leaf node
			PageId newLeafPageNo;
			Page* newLeafPage;
			bufMgr->allocPage(file, newLeafPageNo, newLeafPage);
			LeafNodeInt* newLeafNode = (LeafNodeInt*) newLeafPage;
			for (int k = 0; k < leafOccupancy; k++) {
				newLeafNode->ridArray[k].page_number = Page::INVALID_NUMBER;
			}
			// move last d entries to new node
			for (int l = d; l < leafOccupancy; l++) {
				keyCopy(&(newLeafNode->keyArray[l - d]),
						&(leafNode->keyArray[l]));
				newLeafNode->ridArray[l - d] = leafNode->ridArray[l];
				// Clear the array
				leafNode->ridArray[l].page_number = Page::INVALID_NUMBER;
			}
			// If the insertion position is in the first half entries
			if (insertIndex < d) {
				// shift keys and record ids
				for (int m = leafOccupancy - 1; m > insertIndex; m--) {
					keyCopy(&(leafNode->keyArray[m]),
							&(leafNode->keyArray[m - 1]));
					leafNode->ridArray[m] = leafNode->ridArray[m - 1];
				}
				// insert the entry
				keyCopy(&(leafNode->keyArray[insertIndex]), key);
				leafNode->ridArray[insertIndex] = rid;
			}
			// If the insertion position is in the last half entries
			else {
				// shift keys and record ids
				for (int n = leafOccupancy - 1; n > insertIndex - d; n--) {
					keyCopy(&(newLeafNode->keyArray[n]),
							&(newLeafNode->keyArray[n - 1]));
					newLeafNode->ridArray[n] = newLeafNode->ridArray[n - 1];
				}
				// insert the entry
				keyCopy(&(newLeafNode->keyArray[insertIndex - d]), key);
				newLeafNode->ridArray[insertIndex - d] = rid;
			}
			// Set newChildEntry
			newChildEntry.pageNo = newLeafPageNo;
			keyCopy(&(newChildEntry.key), &(newLeafNode->keyArray[0]));
			// Set right sibling relations
			newLeafNode->rightSibPageNo = leafNode->rightSibPageNo;
			leafNode->rightSibPageNo = newLeafPageNo;
			// unpin the page
			bufMgr->unPinPage(file, newLeafPageNo, true);
			return;
		}
	}
}

// -----------------------------------------------------------------------------
// BTreeIndex::startScanTemplate
// -----------------------------------------------------------------------------

const void BTreeIndex::startScanTemplate(const int* lowVal,
		const Operator lowOp, const int* highVal, const Operator highOp) {
	// Initialize some scan variables
	currentPageNum = rootPageNum;
	bufMgr->readPage(file, currentPageNum, currentPageData);
	nextEntry = 0;
	// Transform to root node
	NonLeafNodeInt* curNode = (NonLeafNodeInt*) currentPageData;
	// Look up through the tree to find the leaf we want
	int pageIndex = -1;
	LeafNodeInt* goalLeaf;
	while (1) {
		// locate the appropriate page to continue
		// lowVal is less than all keys.
		if (keyCompare(lowVal, &(curNode->keyArray[0])) < 0) {
			pageIndex = 0;
		} else {
			for (int i = 0; i < nodeOccupancy; i++) {
				// Go to last available page pointer or go to very last page pointer
				if (i == (nodeOccupancy - 1)
						|| curNode->pageNoArray[i + 2]
								== Page::INVALID_NUMBER) {
					pageIndex = i + 1;
					break;
				}
				// Find appropriate key.
				else if (keyCompare(&(curNode->keyArray[i]), lowVal) <= 0
						&& keyCompare(&(curNode->keyArray[i + 1]), lowVal)
								> 0) {
					pageIndex = i + 1;
					break;
				}
			}
		}
		// unpin current page
		bufMgr->unPinPage(file, currentPageNum, false);
		// switch to the page we just find
		currentPageNum = curNode->pageNoArray[pageIndex];
		bufMgr->readPage(file, currentPageNum, currentPageData);
		if (curNode->level > 1) {
			curNode = (NonLeafNodeInt*) currentPageData;
		} else {
			curNode = NULL;
			goalLeaf = (LeafNodeInt*) currentPageData;
			break;
		}
	}
	// Find the appropriate index in the leaf we get.
	while (1) {
		// conditions for going beyond the high val bound.
		if (highOp == LT
				&& keyCompare(highVal, &(goalLeaf->keyArray[nextEntry])) <= 0) {
			nextEntry = -1;
			break;
		}
		if (highOp == LTE
				&& keyCompare(highVal, &(goalLeaf->keyArray[nextEntry])) < 0) {
			nextEntry = -1;
			break;
		}
		// conditions for finding appropriate index
		if (lowOp == GT
				&& keyCompare(lowVal, &(goalLeaf->keyArray[nextEntry])) < 0) {
			break;
		}
		if (lowOp == GTE
				&& keyCompare(lowVal, &(goalLeaf->keyArray[nextEntry])) <= 0) {
			break;
		}
		// Not meet the conditions, forward the entry.
		nextEntry++;
		// check if it should reach to next page.
		if (nextEntry == leafOccupancy
				|| goalLeaf->ridArray[nextEntry].page_number
						== Page::INVALID_NUMBER) {
			// get next page number
			PageId nextPageNum = goalLeaf->rightSibPageNo;
			// check if next page is invalid
			if (nextPageNum == Page::INVALID_NUMBER) {
				nextEntry = -1;
				return;
			}
			// Unpin current page
			bufMgr->unPinPage(file, currentPageNum, false);
			// read the next page
			currentPageNum = nextPageNum;
			bufMgr->readPage(file, currentPageNum, currentPageData);
			// set the current leaf
			goalLeaf = (LeafNodeInt*) currentPageData;
			// set the entry to the first index of the next page
			nextEntry = 0;
		}
	}
}

// -----------------------------------------------------------------------------
// BTreeIndex::scanNextTemplate
// -----------------------------------------------------------------------------

const void BTreeIndex::scanNextTemplate(RecordId& outRid, int* highVal) {
	// Get the current leaf
	LeafNodeInt* curLeaf = (LeafNodeInt*) currentPageData;
	// return the rid
	outRid = curLeaf->ridArray[nextEntry];
	// forward the nextEntry
	nextEntry++;
	// If the low value is larger than all of the keys in the current leaf
	// or reach the right bound of the current leaf
	if (nextEntry == leafOccupancy
			|| curLeaf->ridArray[nextEntry].page_number
					== Page::INVALID_NUMBER) {
		// get next sibling page number
		PageId nextPageNum = curLeaf->rightSibPageNo;
		// check if next page is invalid
		if (nextPageNum == Page::INVALID_NUMBER) {
			nextEntry = -1;
			return;
		}
		// Unpin current page
		bufMgr->unPinPage(file, currentPageNum, false);
		// read the next sibling page
		currentPageNum = nextPageNum;
		bufMgr->readPage(file, currentPageNum, currentPageData);
		// set current leaf
		curLeaf = (LeafNodeInt*) currentPageData;
		// set the first key as next entry.
		nextEntry = 0;
	}
	// conditions for going beyond the high val bound.
	if (highOp == LT
			&& keyCompare(highVal, &(curLeaf->keyArray[nextEntry])) <= 0) {
		nextEntry = -1;
		return;
	}
	if (highOp == LTE
			&& keyCompare(highVal, &(curLeaf->keyArray[nextEntry])) < 0) {
		nextEntry = -1;
		return;
	}
}

  // -----------------------------------------------------------------------------
  // BTreeIndex::bTreeRoot
  // -----------------------------------------------------------------------------
  const int* BTreeIndex::bTreeRoot() {
    IndexMetaInfo indexMetaInfo;
    PageId root = indexMetaInfo.rootPageNo;
    Page *rootPage = NULL;
    bufMgr->readPage(file, root, rootPage);
    NonLeafNodeInt *currNode = (NonLeafNodeInt*) rootPage;
    return currNode->keyArray;
  }
}
