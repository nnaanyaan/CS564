/**
 * @author See Contributors.txt for code contributors and overview of BadgerDB.
 *
 * @section LICENSE
 * Copyright (c) 2012 Database Group, Computer Sciences Department, University of Wisconsin-Madison.
 */

#include <vector>
#include "btree.h"
#include "page.h"
#include "filescan.h"
#include "page_iterator.h"
#include "file_iterator.h"
#include "exceptions/insufficient_space_exception.h"
#include "exceptions/index_scan_completed_exception.h"
#include "exceptions/file_not_found_exception.h"
#include "exceptions/no_such_key_found_exception.h"
#include "exceptions/bad_scanrange_exception.h"
#include "exceptions/bad_opcodes_exception.h"
#include "exceptions/scan_not_initialized_exception.h"
#include "exceptions/end_of_file_exception.h"

#define checkPassFail(a, b) 																				\
{																																		\
	if(a == b)																												\
		std::cout << "\nTest passed at line no:" << __LINE__ << "\n";		\
	else																															\
	{																																	\
		std::cout << "\nTest FAILS at line no:" << __LINE__;						\
		std::cout << "\nExpected no of records:" << b;									\
		std::cout << "\nActual no of records found:" << a;							\
		std::cout << std::endl;																					\
		exit(1);																												\
	}																																	\
}
using namespace badgerdb;

// -----------------------------------------------------------------------------
// Globals
// -----------------------------------------------------------------------------
int testNum = 1;
const std::string relationName = "relA";
//If the relation size is changed then the second parameter 2 cheched PassFail may need to be changed to number of record that are expected to be found during the scan, else tests wierroneously be reported to have failed.
const int rootRelationSize = 16;
const int smallestRelationSize = 1;
const int relationSize = 5000;
const int largerRelationSize = 100000;
std::string intIndexName, doubleIndexName, stringIndexName;

// This is the structure for tuples in the base relation

typedef struct tuple {
	int i;
	double d;
	char s[64];
} RECORD;

PageFile* file1;
RecordId rid;
RECORD record1;
std::string dbRecord1;

BufMgr * bufMgr = new BufMgr(100);

// -----------------------------------------------------------------------------
// Forward declarations
// -----------------------------------------------------------------------------

void createRelationLowHighMid();
void createRelationForward();
void createRelationBackward();
void createRelationRandom();
void intTestsLowHighMid();
void intTests();
int intScan(BTreeIndex *index, int lowVal, Operator lowOp, int highVal,
		Operator highOp);
void indexTestsLowHighMid();
void indexTests();
void intTestsSmallest();
void createRelationForwardSmallest();
void indexTestsSmallest();
void createRelationForwardLarger();
void createRelationBackwardLarger();
void createRelationRandomLarger();
void intTestsLarger();
void indexTestsLarger();
void test1();
void test2();
void test3();
void test4();
void test5();
void test6();
void test7();
void test8();
void errorTests();
void deleteRelation();
void checkRoot(const int*);
void indexTestsRoot();
void rootTest();
void createRelationForwardRoot();

int main(int argc, char **argv) {

	std::cout << "leaf size:" << INTARRAYLEAFSIZE << " non-leaf size:"
			<< INTARRAYNONLEAFSIZE << std::endl;

	// Clean up from any previous runs that crashed.
	try {
		File::remove(relationName);
	} catch (FileNotFoundException) {
	}

	{
		// Create a new database file.
		PageFile new_file = PageFile::create(relationName);

		// Allocate some pages and put data on them.
		for (int i = 0; i < 20; ++i) {
			PageId new_page_number;
			Page new_page = new_file.allocatePage(new_page_number);

			sprintf(record1.s, "%05d string record", i);
			record1.i = i;
			record1.d = (double) i;
			std::string new_data(reinterpret_cast<char*>(&record1),
					sizeof(record1));

			new_page.insertRecord(new_data);
			new_file.writePage(new_page_number, new_page);
		}

	}
	// new_file goes out of scope here, so file is automatically closed.

	{
		FileScan fscan(relationName, bufMgr);

		try {
			RecordId scanRid;
			while (1) {
				fscan.scanNext(scanRid);
				//Assuming RECORD.i is our key, lets extract the key, which we know is INTEGER and whose byte offset is also know inside the record. 
				std::string recordStr = fscan.getRecord();
				const char *record = recordStr.c_str();
				int key = *((int *) (record + offsetof(RECORD, i)));
				std::cout << "Extracted : " << key << std::endl;
			}
		} catch (EndOfFileException e) {
			std::cout << "Read all records" << std::endl;
		}
	}
	// filescan goes out of scope here, so relation file gets closed.

	File::remove(relationName);

	std::cout << std::endl << "< Start test 1 >" << std::endl << std::endl;
	test1();
	std::cout << std::endl << "< End test 1 >" << std::endl << std::endl;
	std::cout << std::endl << "< Start test 2 >" << std::endl << std::endl;
	test2();
	std::cout << std::endl << "< End test 2 >" << std::endl << std::endl;
	std::cout << std::endl << "< Start test 3 >" << std::endl << std::endl;
	test3();
	std::cout << std::endl << "< End test 3 >" << std::endl << std::endl;
	std::cout << std::endl << "< Start test 4 >" << std::endl << std::endl;
	test4();
	std::cout << std::endl << "< End test 4 >" << std::endl << std::endl;
	std::cout << std::endl << "< Start test 5 >" << std::endl << std::endl;
	test5();
	std::cout << std::endl << "< End test 5 >" << std::endl << std::endl;
	std::cout << std::endl << "< Start test 6 >" << std::endl << std::endl;
	test6();
	std::cout << std::endl << "< End test 6 >" << std::endl << std::endl;
	//std::cout << std::endl << "< Start test 7 >" << std::endl << std::endl;
	//test7();
	//std::cout << std::endl << "< End test 7 >" << std::endl << std::endl;
	//std::cout << std::endl << "< Start test 8 >" << std::endl << std::endl;
	//test8();
	//std::cout << std::endl << "< End test 8 >" << std::endl << std::endl;
	std::cout << std::endl << "< Start errorTests >" << std::endl << std::endl;
        errorTests();
	std::cout << std::endl << "< End errorTests >" << std::endl << std::endl;

	return 1;

}

void test1() {
	// Create a relation with tuples valued 0 to relationSize and perform index tests 
	// on attributes of all three types (int, double, string)
	std::cout << "---------------------" << std::endl;
	std::cout << "createRelationForward" << std::endl;
	createRelationForward();
	indexTests();
	deleteRelation();
}

void test2() {
	// Create a relation with tuples valued 0 to relationSize in reverse order and perform index tests 
	// on attributes of all three types (int, double, string)
	std::cout << "----------------------" << std::endl;
	std::cout << "createRelationBackward" << std::endl;
	createRelationBackward();
	indexTests();
	deleteRelation();
}

void test3() {
	// Create a relation with tuples valued 0 to relationSize in random order and perform index tests 
	// on attributes of all three types (int, double, string)
	std::cout << "--------------------" << std::endl;
	std::cout << "createRelationRandom" << std::endl;
	createRelationRandom();
	indexTests();
	deleteRelation();
}

void test4() {
	// Create a relation with tuples valued 0 to largerRelationSize and perform index tests
	// on attributes of all three types (int, double, string)
	std::cout << "---------------------" << std::endl;
	std::cout << "createRelationForward" << std::endl;
	createRelationForwardLarger();
	indexTestsLarger();
	deleteRelation();
}

void test5() {
	// Create a relation with tuples valued 0 to largerRelationSize in reverse order and perform index tests
	// on attributes of all three types (int, double, string)
	std::cout << "----------------------" << std::endl;
	std::cout << "createRelationBackward" << std::endl;
	createRelationBackwardLarger();
	indexTestsLarger();
	deleteRelation();
}

void test6() {
	// Create a relation with tuples valued 0 to relationSize in random order and perform index tests
	// on attributes of all three types (int, double, string)
	std::cout << "--------------------" << std::endl;
	std::cout << "createRelationRandom" << std::endl;
	createRelationRandomLarger();
	indexTestsLarger();
	deleteRelation();
}
//void test7() {
	// Create a relation with tuples valued 0 to smallestRelationSize in random order and perform index tests
	// on attributes of all three types (int, double, string)
//  std::cout << "--------------------" << std::endl;
//  std::cout << "createRelationForwardSmallest" << std::endl;
//  createRelationForwardSmallest();
//  std::cout << "@@@@@@TEST LINE A" << std::endl;
//  indexTestsSmallest();
//  std::cout << "@@@@@@TEST LINE B" << std::endl;
//  deleteRelation();
//  std::cout << "@@@@@@TEST LINE C" << std::endl;

//}

//void test8() {
	// Create a relation with tuples valued 0 to 10, 490 to 500, and 990 to 1000 ...
        //ascending order and perform index tests
	// on attributes of all three types (int, double, string)
//  std::cout << "--------------------" << std::endl;
//  std::cout << "createRelationLowHighMid" << std::endl;
//  createRelationLowHighMid();
//  std::cout << "@@@@@@TEST LINE D" << std::endl;
//  indexTestsLowHighMid();
//  std::cout << "@@@@@@TEST LINE E" << std::endl;
//  deleteRelation();
//  std::cout << "@@@@@@TEST LINE F" << std::endl;

//}

//test8 that Laura had (still can't get this to work)
/*
void test8() {
  std::cout << "--------------------" << std::endl;
  std::cout << "createRelationForwardRoot" << std::endl;
  createRelationForwardRoot();
  std::cout << "@@@@@@TEST LINE D" << std::endl;
  indexTestsRoot();
  std::cout << "@@@@@@TEST LINE E" << std::endl;
  deleteRelation();
  std::cout << "@@@@@@TEST LINE F" << std::endl;

}
*/

// -----------------------------------------------------------------------------
// createRelationLowHighMid
// -----------------------------------------------------------------------------

void createRelationLowHighMid() {
	std::vector < RecordId > ridVec;
	// destroy any old copies of relation file
	try {
		File::remove(relationName);
	} catch (FileNotFoundException e) {
	}

	file1 = new PageFile(relationName, true);

	// initialize all of record1.s to keep purify happy
	memset(record1.s, ' ', sizeof(record1.s));
	PageId new_page_number;
	Page new_page = file1->allocatePage(new_page_number);

	// Insert 10 tuples in low indexes (1 - 10)
	for (int i = 1; i <= 10; i++) {
		sprintf(record1.s, "%05d string record", i);
		record1.i = i;
		record1.d = (double) i;
		std::string new_data(reinterpret_cast<char*>(&record1),
				sizeof(record1));

		while (1) {
			try {
				new_page.insertRecord(new_data);
				break;
			} catch (InsufficientSpaceException e) {
				file1->writePage(new_page_number, new_page);
				new_page = file1->allocatePage(new_page_number);
			}
		}
	}

	// Insert 10 tuples in low indexes (491 - 500)
	for (int i = 991; i <= 1000; i++) {
		sprintf(record1.s, "%05d string record", i);
		record1.i = i;
		record1.d = (double) i;
		std::string new_data(reinterpret_cast<char*>(&record1),
				sizeof(record1));

		while (1) {
			try {
				new_page.insertRecord(new_data);
				break;
			} catch (InsufficientSpaceException e) {
				file1->writePage(new_page_number, new_page);
				new_page = file1->allocatePage(new_page_number);
			}
		}
	}

	// Insert 10 tuples in low indexes (991 - 1000)
	for (int i = 491; i <= 500; i++) {
		sprintf(record1.s, "%05d string record", i);
		record1.i = i;
		record1.d = (double) i;
		std::string new_data(reinterpret_cast<char*>(&record1),
				sizeof(record1));

		while (1) {
			try {
				new_page.insertRecord(new_data);
				break;
			} catch (InsufficientSpaceException e) {
				file1->writePage(new_page_number, new_page);
				new_page = file1->allocatePage(new_page_number);
			}
		}
	}

	file1->writePage(new_page_number, new_page);
}

// -----------------------------------------------------------------------------
// createRelationForward
// -----------------------------------------------------------------------------

void createRelationForward() {
	std::vector < RecordId > ridVec;
	// destroy any old copies of relation file
	try {
		File::remove(relationName);
	} catch (FileNotFoundException e) {
	}

	file1 = new PageFile(relationName, true);

	// initialize all of record1.s to keep purify happy
	memset(record1.s, ' ', sizeof(record1.s));
	PageId new_page_number;
	Page new_page = file1->allocatePage(new_page_number);

	// Insert a bunch of tuples into the relation.
	for (int i = 0; i < relationSize; i++) {
		sprintf(record1.s, "%05d string record", i);
		record1.i = i;
		record1.d = (double) i;
		std::string new_data(reinterpret_cast<char*>(&record1),
				sizeof(record1));

		while (1) {
			try {
				new_page.insertRecord(new_data);
				break;
			} catch (InsufficientSpaceException e) {
				file1->writePage(new_page_number, new_page);
				new_page = file1->allocatePage(new_page_number);
			}
		}
	}

	file1->writePage(new_page_number, new_page);
}
// -----------------------------------------------------------------------------
// createRelationForwardRoot
// -----------------------------------------------------------------------------

void createRelationForwardRoot() {
  std::vector < RecordId > ridVec;
  // destroy any old copies of relation file
  try {
    File::remove(relationName);
  } catch (FileNotFoundException e) {
  }

  file1 = new PageFile(relationName, true);

  // initialize all of record1.s to keep purify happy
  memset(record1.s, ' ', sizeof(record1.s));
  PageId new_page_number;
  Page new_page = file1->allocatePage(new_page_number);

  // Insert a bunch of tuples into the relation.
  for (int i = 0; i < rootRelationSize; i++) {
    sprintf(record1.s, "%05d string record", i);
    record1.i = i;
    record1.d = (double) i;
    std::string new_data(reinterpret_cast<char*>(&record1),
			 sizeof(record1));

    while (1) {
      try {
	new_page.insertRecord(new_data);
	break;
      } catch (InsufficientSpaceException e) {
	file1->writePage(new_page_number, new_page);
	new_page = file1->allocatePage(new_page_number);
      }
    }
  }

  file1->writePage(new_page_number, new_page);
}

// -----------------------------------------------------------------------------
// createRelationForwardSmallest
// -----------------------------------------------------------------------------
void createRelationForwardSmallest() {
	std::vector < RecordId > ridVec;
	// destroy any old copies of relation file
	try {
		File::remove(relationName);
	} catch (FileNotFoundException e) {
	}

	file1 = new PageFile(relationName, true);

	// initialize all of record1.s to keep purify happy
	memset(record1.s, ' ', sizeof(record1.s));
	PageId new_page_number;
	Page new_page = file1->allocatePage(new_page_number);

	// Insert a bunch of tuples into the relation.
	for (int i = 0; i < smallestRelationSize; i++) {
		sprintf(record1.s, "%05d string record", i);
		record1.i = i;
		record1.d = (double) i;
		std::string new_data(reinterpret_cast<char*>(&record1),
				sizeof(record1));

		while (1) {
			try {
				new_page.insertRecord(new_data);
				break;
			} catch (InsufficientSpaceException e) {
				file1->writePage(new_page_number, new_page);
				new_page = file1->allocatePage(new_page_number);
			}
		}
	}

	file1->writePage(new_page_number, new_page);
}


void createRelationForwardLarger() {
	std::vector < RecordId > ridVec;
	// destroy any old copies of relation file
	try {
		File::remove(relationName);
	} catch (FileNotFoundException e) {
	}

	file1 = new PageFile(relationName, true);

	// initialize all of record1.s to keep purify happy
	memset(record1.s, ' ', sizeof(record1.s));
	PageId new_page_number;
	Page new_page = file1->allocatePage(new_page_number);

	// Insert a bunch of tuples into the relation.
	for (int i = 0; i < largerRelationSize; i++) {
		sprintf(record1.s, "%05d string record", i);
		record1.i = i;
		record1.d = (double) i;
		std::string new_data(reinterpret_cast<char*>(&record1),
				sizeof(record1));

		while (1) {
			try {
				new_page.insertRecord(new_data);
				break;
			} catch (InsufficientSpaceException e) {
				file1->writePage(new_page_number, new_page);
				new_page = file1->allocatePage(new_page_number);
			}
		}
	}

	file1->writePage(new_page_number, new_page);
}

// -----------------------------------------------------------------------------
// createRelationBackward
// -----------------------------------------------------------------------------

void createRelationBackward() {
	// destroy any old copies of relation file
	try {
		File::remove(relationName);
	} catch (FileNotFoundException e) {
	}
	file1 = new PageFile(relationName, true);

	// initialize all of record1.s to keep purify happy
	memset(record1.s, ' ', sizeof(record1.s));
	PageId new_page_number;
	Page new_page = file1->allocatePage(new_page_number);

	// Insert a bunch of tuples into the relation.
	for (int i = relationSize - 1; i >= 0; i--) {
		sprintf(record1.s, "%05d string record", i);
		record1.i = i;
		record1.d = i;

		std::string new_data(reinterpret_cast<char*>(&record1), sizeof(RECORD));

		while (1) {
			try {
				new_page.insertRecord(new_data);
				break;
			} catch (InsufficientSpaceException e) {
				file1->writePage(new_page_number, new_page);
				new_page = file1->allocatePage(new_page_number);
			}
		}
	}

	file1->writePage(new_page_number, new_page);
}
// -----------------------------------------------------------------------------
// createRelationBackwardLarger
// -----------------------------------------------------------------------------

void createRelationBackwardLarger() {
	// destroy any old copies of relation file
	try {
		File::remove(relationName);
	} catch (FileNotFoundException e) {
	}
	file1 = new PageFile(relationName, true);

	// initialize all of record1.s to keep purify happy
	memset(record1.s, ' ', sizeof(record1.s));
	PageId new_page_number;
	Page new_page = file1->allocatePage(new_page_number);

	// Insert a bunch of tuples into the relation.
	for (int i = largerRelationSize - 1; i >= 0; i--) {
		sprintf(record1.s, "%05d string record", i);
		record1.i = i;
		record1.d = i;

		std::string new_data(reinterpret_cast<char*>(&record1), sizeof(RECORD));

		while (1) {
			try {
				new_page.insertRecord(new_data);
				break;
			} catch (InsufficientSpaceException e) {
				file1->writePage(new_page_number, new_page);
				new_page = file1->allocatePage(new_page_number);
			}
		}
	}

	file1->writePage(new_page_number, new_page);
}
// -----------------------------------------------------------------------------
// createRelationRandom
// -----------------------------------------------------------------------------

void createRelationRandom() {
	// destroy any old copies of relation file
	try {
		File::remove(relationName);
	} catch (FileNotFoundException e) {
	}
	file1 = new PageFile(relationName, true);

	// initialize all of record1.s to keep purify happy
	memset(record1.s, ' ', sizeof(record1.s));
	PageId new_page_number;
	Page new_page = file1->allocatePage(new_page_number);

	// insert records in random order

	std::vector<int> intvec(relationSize);
	for (int i = 0; i < relationSize; i++) {
		intvec[i] = i;
	}

	long pos;
	int val;
	int i = 0;
	while (i < relationSize) {
		pos = random() % (relationSize - i);
		val = intvec[pos];
		sprintf(record1.s, "%05d string record", val);
		record1.i = val;
		record1.d = val;

		std::string new_data(reinterpret_cast<char*>(&record1), sizeof(RECORD));

		while (1) {
			try {
				new_page.insertRecord(new_data);
				break;
			} catch (InsufficientSpaceException e) {
				file1->writePage(new_page_number, new_page);
				new_page = file1->allocatePage(new_page_number);
			}
		}

		int temp = intvec[relationSize - 1 - i];
		intvec[relationSize - 1 - i] = intvec[pos];
		intvec[pos] = temp;
		i++;
	}

	file1->writePage(new_page_number, new_page);
}
// -----------------------------------------------------------------------------
// createRelationRandomLarger
// -----------------------------------------------------------------------------

void createRelationRandomLarger() {
	// destroy any old copies of relation file
	try {
		File::remove(relationName);
	} catch (FileNotFoundException e) {
	}
	file1 = new PageFile(relationName, true);

	// initialize all of record1.s to keep purify happy
	memset(record1.s, ' ', sizeof(record1.s));
	PageId new_page_number;
	Page new_page = file1->allocatePage(new_page_number);

	// insert records in random order

	std::vector<int> intvec(largerRelationSize);
	for (int i = 0; i < largerRelationSize; i++) {
		intvec[i] = i;
	}

	long pos;
	int val;
	int i = 0;
	while (i < largerRelationSize) {
		pos = random() % (largerRelationSize - i);
		val = intvec[pos];
		sprintf(record1.s, "%05d string record", val);
		record1.i = val;
		record1.d = val;

		std::string new_data(reinterpret_cast<char*>(&record1), sizeof(RECORD));

		while (1) {
			try {
				new_page.insertRecord(new_data);
				break;
			} catch (InsufficientSpaceException e) {
				file1->writePage(new_page_number, new_page);
				new_page = file1->allocatePage(new_page_number);
			}
		}

		int temp = intvec[largerRelationSize - 1 - i];
		intvec[largerRelationSize - 1 - i] = intvec[pos];
		intvec[pos] = temp;
		i++;
	}

	file1->writePage(new_page_number, new_page);
}


// -----------------------------------------------------------------------------
// indexTestsLowHighMid
// -----------------------------------------------------------------------------

//void indexTestsLowHighMid() {
//	if (testNum == 1) {
//		intTestsLowHighMid();
//		try {
//			File::remove(intIndexName);
//		} catch (FileNotFoundException e) {
//		}
//	}
//}

// -----------------------------------------------------------------------------
// indexTests
// -----------------------------------------------------------------------------

void indexTests() {
	if (testNum == 1) {
		intTests();
		try {
			File::remove(intIndexName);
		} catch (FileNotFoundException e) {
		}
	}
}

// -----------------------------------------------------------------------------
// indexTestsRoot
// -----------------------------------------------------------------------------

void indexTestsRoot() {
	if (testNum == 1) {
		rootTest();
		try {
			File::remove(intIndexName);
		} catch (FileNotFoundException e) {
		}
	}
}

// -----------------------------------------------------------------------------
// indexTestsSmallest
// -----------------------------------------------------------------------------

//void indexTestsSmallest() {
//  if (testNum == 1) {
//   intTestsSmallest();
//    try {
//     File::remove(intIndexName);
//    } catch (FileNotFoundException e) {
//  }
//}
//}

// -----------------------------------------------------------------------------
// indexTestsLarger
// -----------------------------------------------------------------------------
void indexTestsLarger() {
	if (testNum == 1) {
		intTestsLarger();
		try {
			File::remove(intIndexName);
		} catch (FileNotFoundException e) {
		}
	}
}

// -----------------------------------------------------------------------------
// indexTestsLowHighMid
// -----------------------------------------------------------------------------

//void intTestsLowHighMid() {
//	std::cout << "Create a B+ Tree index on the integer field" << std::endl;
//	BTreeIndex index(relationName, intIndexName, bufMgr, offsetof(tuple,i), INTEGER);

	// run some tests
//	checkPassFail(intScan(&index,-1,GT,11,LT), 10) // this passes 
	// this passes and shows there are 30 inputs (just dont know where they are
//        checkPassFail(intScan(&index,-1,GT,1001,LT), 30) 

//	checkPassFail(intScan(&index,490,GTE,500,LTE), 10) // this fails
//	checkPassFail(intScan(&index,990,GTE,1000,LTE), 10) //this fails

//}


// -----------------------------------------------------------------------------
// indexTests
// -----------------------------------------------------------------------------

void intTests() {
	std::cout << "Create a B+ Tree index on the integer field" << std::endl;
	BTreeIndex index(relationName, intIndexName, bufMgr, offsetof(tuple,i), INTEGER);

	// run some tests
	checkPassFail(intScan(&index,25,GT,40,LT), 14)
	checkPassFail(intScan(&index,20,GTE,35,LTE), 16)
	checkPassFail(intScan(&index,-3,GT,3,LT), 3)
	checkPassFail(intScan(&index,996,GT,1001,LT), 4)
	checkPassFail(intScan(&index,0,GT,1,LT), 0)
	checkPassFail(intScan(&index,300,GT,400,LT), 99)
	checkPassFail(intScan(&index,3000,GTE,4000,LT), 1000)
}

// -----------------------------------------------------------------------------
// smallestIndexTests
// -----------------------------------------------------------------------------

void intTestsSmallest() {
  std::cout << "Create a B+ Tree index on the integer field" << std::endl\
    ;
  BTreeIndex index(relationName, intIndexName, bufMgr, offsetof(tuple,i),\
		   INTEGER);

  // run some tests
    checkPassFail(intScan(&index,0,GTE,1,LTE), 0) // allows the code to move on to test 8
    //checkPassFail(intScan(&index,0,GTE,0,LTE), 1) --> this was the line you had that failed laura 
    }

// -----------------------------------------------------------------------------
// intTestsLarger
// -----------------------------------------------------------------------------
void intTestsLarger() {
	std::cout << "Create a B+ Tree index on the integer field" << std::endl;
	BTreeIndex index(relationName, intIndexName, bufMgr, offsetof(tuple,i), INTEGER);

	// run some tests
	checkPassFail(intScan(&index,125,GT,400,LT), 274)
	checkPassFail(intScan(&index,120,GTE,355,LTE), 236)
	checkPassFail(intScan(&index,-10,GT,155,LT), 155)
	checkPassFail(intScan(&index,996,GT,1001,LT), 4)
	checkPassFail(intScan(&index,0,GTE,0,LTE), 1)
	checkPassFail(intScan(&index,3000,GT,7000,LT), 3999)
	checkPassFail(intScan(&index,6000,GTE,9000,LT), 3000)
}
// -----------------------------------------------------------------------------
// rootTest
// -----------------------------------------------------------------------------
void rootTest() {
  std::cout << "Create a B+ Tree index on the integer field" << std::endl;
  BTreeIndex index(relationName, intIndexName, bufMgr, offsetof(tuple,i), INTEGER);

  // run some tests
  checkRoot(index.bTreeRoot());


  
}

void checkRoot(const int * rootKeys) {
  //here check root keys are equal to expected root keys 
}
int intScan(BTreeIndex * index, int lowVal, Operator lowOp, int highVal, Operator highOp)
{
	RecordId scanRid;
	Page *curPage;

	std::cout << "Scan for ";
	if( lowOp == GT ) {std::cout << "(";} else {std::cout << "[";}
	std::cout << lowVal << "," << highVal;
	if( highOp == LT ) {std::cout << ")";} else {std::cout << "]";}
	std::cout << std::endl;

	int numResults = 0;

	try
	{
		index->startScan(&lowVal, lowOp, &highVal, highOp);
	}
	catch(NoSuchKeyFoundException e)
	{
		std::cout << "No Key Found satisfying the scan criteria." << std::endl;
		return 0;
	}

	while(1)
	{
		try
		{
			index->scanNext(scanRid);
			bufMgr->readPage(file1, scanRid.page_number, curPage);
			RECORD myRec = *(reinterpret_cast<const RECORD*>(curPage->getRecord(scanRid).data()));
			bufMgr->unPinPage(file1, scanRid.page_number, false);

			if( numResults < 5 )
			{
				std::cout << "at:" << scanRid.page_number << "," << scanRid.slot_number;
				std::cout << " -->:" << myRec.i << ":" << myRec.d << ":" << myRec.s << ":" <<std::endl;
			}
			else if( numResults == 5 )
			{
				std::cout << "..." << std::endl;
			}
		}
		catch(IndexScanCompletedException e)
		{
			break;
		}

		numResults++;
	}

	if( numResults >= 5 )
	{
		std::cout << "Number of results: " << numResults << std::endl;
	}
	index->endScan();
	std::cout << std::endl;

	return numResults;
}

// -----------------------------------------------------------------------------
// errorTests
// -----------------------------------------------------------------------------

void errorTests()
{
	std::cout << "Error handling tests" << std::endl;
	std::cout << "--------------------" << std::endl;
	// Given error test

	try
	{
		File::remove(relationName);
	}
	catch(FileNotFoundException e)
	{
	}

	file1 = new PageFile(relationName, true);

	// initialize all of record1.s to keep purify happy
	memset(record1.s, ' ', sizeof(record1.s));
	PageId new_page_number;
	Page new_page = file1->allocatePage(new_page_number);

	// Insert a bunch of tuples into the relation.
	for(int i = 0; i <10; i++ )
	{
		sprintf(record1.s, "%05d string record", i);
		record1.i = i;
		record1.d = (double)i;
		std::string new_data(reinterpret_cast<char*>(&record1), sizeof(record1));

		while(1)
		{
			try
			{
				new_page.insertRecord(new_data);
				break;
			}
			catch(InsufficientSpaceException e)
			{
				file1->writePage(new_page_number, new_page);
				new_page = file1->allocatePage(new_page_number);
			}
		}
	}

	file1->writePage(new_page_number, new_page);

	BTreeIndex index(relationName, intIndexName, bufMgr, offsetof(tuple,i), INTEGER);

	int int2 = 2;
	int int5 = 5;

	// Scan Tests
	std::cout << "Call endScan before startScan" << std::endl;
	try
	{
		index.endScan();
		std::cout << "ScanNotInitialized Test 1 Failed." << std::endl;
	}
	catch(ScanNotInitializedException e)
	{
		std::cout << "ScanNotInitialized Test 1 Passed." << std::endl;
	}

	std::cout << "Call scanNext before startScan" << std::endl;
	try
	{
		RecordId foo;
		index.scanNext(foo);
		std::cout << "ScanNotInitialized Test 2 Failed." << std::endl;
	}
	catch(ScanNotInitializedException e)
	{
		std::cout << "ScanNotInitialized Test 2 Passed." << std::endl;
	}

	std::cout << "Scan with bad lowOp" << std::endl;
	try
	{
		index.startScan(&int2, LTE, &int5, LTE);
		std::cout << "BadOpcodesException Test 1 Failed." << std::endl;
	}
	catch(BadOpcodesException e)
	{
		std::cout << "BadOpcodesException Test 1 Passed." << std::endl;
	}

	std::cout << "Scan with bad highOp" << std::endl;
	try
	{
		index.startScan(&int2, GTE, &int5, GTE);
		std::cout << "BadOpcodesException Test 2 Failed." << std::endl;
	}
	catch(BadOpcodesException e)
	{
		std::cout << "BadOpcodesException Test 2 Passed." << std::endl;
	}

	std::cout << "Scan with bad range" << std::endl;
	try
	{
		index.startScan(&int5, GTE, &int2, LTE);
		std::cout << "BadScanrangeException Test 1 Failed." << std::endl;
	}
	catch(BadScanrangeException e)
	{
		std::cout << "BadScanrangeException Test 1 Passed." << std::endl;
	}

	deleteRelation();
}

void deleteRelation()
{
	if(file1)
	{
		bufMgr->flushFile(file1);
		delete file1;
		file1 = NULL;
	}
	try
	{
		File::remove(relationName);
	}
	catch(FileNotFoundException e)
	{
	}
}
