DROP VIEW IF EXISTS Baconmovie;

CREATE VIEW Baconmovie AS
SELECT casts.mid
FROM casts, actor
WHERE casts.pid = actor.id
    AND actor.fname = 'Kevin'
    AND actor.lname = 'Bacon' ;

DROP VIEW IF EXISTS B1list;

CREATE VIEW B1list AS
SELECT A1.id AS pid
FROM actor A1, casts C1
WHERE C1.mid IN (SELECT mid FROM Baconmovie)
    AND A1.id = C1.pid
    AND NOT (A1.fname = 'Kevin'
            AND A1.lname = 'Bacon') ;

SELECT COUNT(DISTINCT A3.id) AS numactorsBaconnumber2
FROM actor A2, actor A3, casts C2, casts C3
WHERE C2.mid NOT IN (SELECT mid FROM Baconmovie)
    AND C2.pid = A2.id
    AND C2.mid = C3.mid
    AND C3.pid = A3.id
    AND NOT (A2.id = A3.id)
    AND A2.id IN (SELECT pid FROM B1list)
    AND A3.id NOT IN (SELECT pid FROM B1list) ;
