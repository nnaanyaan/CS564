SELECT Store
FROM Stores
WHERE Store NOT IN (
    SELECT DISTINCT Store
    FROM (
        SELECT Store, Dept, MAX(Counter) AS Counter2
        FROM (
            SELECT Store, Dept, Year, COUNT(DISTINCT Month) AS Counter
            FROM (
                SELECT Store, Dept, SUBSTR(WeekDate, 1, 4) AS Year, SUBSTR(WeekDate, 6, 2) AS Month
                FROM Salesnew
                WHERE SUBSTR(WeekDate, 1, 4) IN ('2010', '2011', '2012')
            )
            GROUP BY Store, Dept, Year
        )
        GROUP BY Store, Dept
    )
    WHERE NOT (Counter2 = 12)
) ;