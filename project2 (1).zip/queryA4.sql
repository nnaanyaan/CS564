DROP VIEW IF EXISTS HolSales;
CREATE VIEW HolSales AS
SELECT H.WeekDate, H.IsHoliday,
SUM (S.WeeklySales) AS AllSales
FROM Salesnew S, Holidays H
WHERE S.WeekDate = H.WeekDate
GROUP BY H.WeekDate, H.IsHoliday;
SELECT COUNT(*)
FROM HolSales
WHERE IsHoliday = "FALSE" AND
AllSales > (SELECT AVG (AllSales)
FROM HolSales
WHERE IsHoliday = "TRUE");