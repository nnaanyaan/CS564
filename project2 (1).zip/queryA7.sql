DROP TABLE IF EXISTS Output7 ;

CREATE TABLE Output7 (AttributeName VARCHAR(20), CorrelationSign INTEGER) ;

INSERT INTO Output7
VALUES ('Temperature', 0) ;

INSERT INTO Output7
VALUES ('FuelPrice', 0) ;

INSERT INTO Output7
VALUES ('CPI', 0) ;

INSERT INTO Output7
VALUES ('UnemploymentRate', 0) ;

DROP VIEW IF EXISTS TempTotalData ;

CREATE VIEW TempTotalData AS
SELECT S.Store, S.Dept, S.WeekDate,
        S.WeeklySales, T.Temperature,
        T.FuelPrice, T.CPI, T.UnemploymentRate
FROM Salesnew S, TemporalData T
WHERE S.Store = T.Store AND S.WeekDate = T.WeekDate ;

DROP VIEW IF EXISTS AvgData ;

CREATE VIEW AvgData AS
SELECT AVG(WeeklySales) AS AvgWeeklySales,
        AVG(Temperature) AS AvgTemperature,
        AVG(FuelPrice) AS AvgFuelPrice,
        AVG(CPI) AS AvgCPI,
        AVG(UnemploymentRate) AS AvgUnemploymentRate
FROM TempTotalData ;

DROP VIEW IF EXISTS TempResult ;

CREATE VIEW TempResult AS
SELECT SUM((WeeklySales - AvgWeeklySales) * (Temperature - AvgTemperature)) AS ResultTemperature,
        SUM((WeeklySales - AvgWeeklySales) * (FuelPrice - AvgFuelPrice)) AS ResultFuelPrice,
        SUM((WeeklySales - AvgWeeklySales) * (CPI - AvgCPI)) AS ResultCPI,
        SUM((WeeklySales - AvgWeeklySales) * (UnemploymentRate - AvgUnemploymentRate)) AS ResultUnemploymentRate
FROM TempTotalData, AvgData ;

UPDATE Output7
SET CorrelationSign = (
    SELECT IFNULL(CAST((ResultTemperature / ABS(ResultTemperature)) AS INTEGER), 0)
    FROM TempResult
)
WHERE AttributeName = 'Temperature' ;

UPDATE Output7
SET CorrelationSign = (
    SELECT IFNULL(CAST((ResultFuelPrice / ABS(ResultFuelPrice)) AS INTEGER), 0)
    FROM TempResult
)
WHERE AttributeName = 'FuelPrice' ;

UPDATE Output7
SET CorrelationSign = (
    SELECT IFNULL(CAST((ResultCPI / ABS(ResultCPI)) AS INTEGER), 0)
    FROM TempResult
)
WHERE AttributeName = 'CPI' ;

UPDATE Output7
SET CorrelationSign = (
    SELECT IFNULL(CAST((ResultUnemploymentRate / ABS(ResultUnemploymentRate)) AS INTEGER), 0)
    FROM TempResult
)
WHERE AttributeName = 'UnemploymentRate' ;

SELECT *
FROM Output7 ;
