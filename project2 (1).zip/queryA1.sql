DROP VIEW IF EXISTS HolSales;
CREATE VIEW HolSales AS
SELECT S.Store, SUM (S.WeeklySales) AS AllSales
FROM Salesnew S, Holidays H
WHERE S.WeekDate = H.WeekDate AND H.IsHoliday = "TRUE"
GROUP BY S.Store;
SELECT Store, AllSales
FROM HolSales
WHERE AllSales = (SELECT MAX (AllSales) FROM HolSales) OR
AllSales = (SELECT MIN (AllSales) FROM HolSales);
