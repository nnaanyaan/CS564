SELECT a.fname, a.lname
FROM actor a, casts c, movie m, directors d, movie_directors md
WHERE a.id = c.pid
AND c.mid = m.id
AND m.id = md.mid
AND md.did = d.id
AND m.year = 2000
AND a.fname = d.fname
AND a.lname = d.lname
GROUP BY a.id, a.fname, a.lname;

