SELECT DISTINCT S.Store
FROM Salesnew S, TemporalData T
WHERE S.Store = T.Store AND S.WeekDate = T.WeekDate AND
T.UnemploymentRate > 10
EXCEPT
SELECT DISTINCT S.Store
FROM Salesnew S, TemporalData T
WHERE S.Store = T.Store AND S.WeekDate = T.WeekDate AND
T.FuelPrice > 4;