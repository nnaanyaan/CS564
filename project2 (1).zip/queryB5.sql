WITH Decade(year, movie_count) AS
(
SELECT y.year, COUNT(*)
FROM (SELECT DISTINCT m.year FROM movie m) y, movie m
WHERE y.year <= m.year AND m.year < y.year+10
GROUP BY y.year
)
SELECT d.year, d.movie_count
FROM Decade d
WHERE d.movie_count =
(SELECT MAX(d.movie_count) FROM Decade d) ;