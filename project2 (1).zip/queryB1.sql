SELECT a.fname, a.lname
FROM actor a, casts c, movie m
WHERE a.id = c.pid
AND c.mid = m.id
AND m.year = 2010
GROUP BY a.id, a.fname, a.lname
HAVING COUNT(DISTINCT m.id) > 9 ;