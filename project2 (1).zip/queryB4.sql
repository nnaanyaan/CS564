SELECT M2.year, COUNT(*) nummovies
FROM movie M2
WHERE M2.id NOT IN (
    SELECT C.mid
    FROM movie M, casts C, actor A
    WHERE M.id = C.mid
        AND C.pid = A.id
        AND A.gender = 'M'
)
    AND NOT (M2.year = '')
GROUP BY M2.year
ORDER BY M2.year ;
