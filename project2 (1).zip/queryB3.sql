SELECT d.fname, d.lname, COUNT(DISTINCT m.id) AS movie_count
FROM movie m, movie_directors md, directors d
WHERE m.id = md.mid
AND md.did = d.id
AND m.year >= 1990 AND m.year <= 2010
GROUP BY d.id, d.fname, d.lname
ORDER BY movie_count DESC
LIMIT 100 ;