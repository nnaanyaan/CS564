SELECT R.Type, substr (S.WeekDate, 6, 2) AS Month,
SUM (S.WeeklySales)
FROM Stores R, Salesnew S
WHERE R.Store = S.Store
GROUP BY R.Type, Month;