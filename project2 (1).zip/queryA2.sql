SELECT S.Dept, SUM (S.WeeklySales / R.Size) AS AllSales
FROM Salesnew S, Stores R
WHERE S.Store = R.Store
GROUP BY S.Dept
ORDER BY AllSales DESC
LIMIT 20;