--CS 564 Project 1 ~ Midas Rhoda, Laura Laidlaw, Yan Nan


-- Drop tables if they already exist
PRAGMA foreign_keys=OFF;

DROP TABLE IF EXISTS Book;
DROP TABLE IF EXISTS Ebook;
DROP TABLE IF EXISTS PrintBook;
DROP TABLE IF EXISTS Author;
DROP TABLE IF EXISTS Publisher;
DROP TABLE IF EXISTS User;
DROP TABLE IF EXISTS Review;
DROP TABLE IF EXISTS Store;
DROP TABLE IF EXISTS Sells;
DROP TABLE IF EXISTS Writes;
DROP TABLE IF EXISTS Distributes;

-- Helps ensure foreign key constraints 

PRAGMA foreign_keys=ON;
 

Create Table Book (	bname CHAR [50],
			edition INTEGER,
			length INTEGER,
			genre CHAR[20],
			pName Char[50],
			ISBN CHAR[13] NOT NULL,
			PRIMARY KEY (ISBN),
			FOREIGN KEY (pName) REFERENCES Publisher
				ON DELETE CASCADE);
				
Create Table Publisher (pname CHAR[50],
			PRIMARY KEY (pname));
				
Create Table Author (	aname CHAR[50],
			Unique(aName),
			PRIMARY KEY (aname));
			

Create Table Writes ( 	ISBN CHAR[13],
			aName CHAR[50],
			PRIMARY KEY (ISBN, aName),
			FOREIGN KEY (ISBN) REFERENCES Book
			ON DELETE CASCADE,
			FOREIGN KEY (aName) REFERENCES Author
			ON DELETE CASCADE);

Create Table Ebook (	price REAL,
			fileSize REAL,
			website CHAR[100],
			ISBN CHAR[13],
			UNIQUE (website, ISBN),
			PRIMARY KEY (website, ISBN),
			FOREIGN KEY (ISBN) REFERENCES Book
			ON DELETE CASCADE);
			
Create Table User (	uid CHAR[25],
			password CHAR [25],
			email CHAR[50],
			PRIMARY KEY (uid));
			
Create Table Store ( 	sName CHAR[50],
			address CHAR[50],
			PRIMARY KEY (address));

Create Table PrintBook (price REAL,
			newUsed INTEGER,
			ISBN CHAR[13],
			PRIMARY KEY (price, newUsed, ISBN),
			FOREIGN KEY (ISBN) REFERENCES Book
			ON DELETE CASCADE);
			
Create Table Sells ( 	ISBN CHAR[13],
			uid CHAR[25],
			newUsed Integer,
			PRIMARY KEY (ISBN, uid)
			FOREIGN KEY (ISBN) REFERENCES Book
			ON DELETE CASCADE,
			FOREIGN KEY (uid) REFERENCES User
			ON DELETE CASCADE);
			

Create Table Distributes ( 	ISBN CHAR[13],
			address CHAR[50],
			PRIMARY KEY (address, ISBN)
			FOREIGN KEY (address) REFERENCES Store
			ON DELETE CASCADE,
			FOREIGN KEY (ISBN) REFERENCES Book
			ON DELETE CASCADE);

Create Table Review (	rating INTEGER,
			comment CHAR[200],
			dateTime datetime,
			ISBN CHAR[13],
			uid CHAR[25],
			PRIMARY KEY (dateTime, ISBN, uid),
			FOREIGN KEY (uid) REFERENCES User,
			FOREIGN KEY (ISBN) REFERENCES Book
				ON DELETE CASCADE);
		

INSERT 
INTO Book (bname, edition, length, genre, ISBN)
VALUES ('Animal Farm', 1, 112, 'Political Satire', '9780736692427');

INSERT 
INTO Book (bname, edition, length, genre, ISBN)
VALUES ('Harry Potter and the Sorcerer''s Stone', 3, 309, 'Fantasy', '9780439708180');

INSERT 
INTO Publisher (pname)
VALUES ('Harcourt, Brace and Company');

INSERT 
INTO Publisher (pname)
VALUES ('Scholastic');

INSERT 
INTO Author (aname)
VALUES ('George Orwell');

INSERT 
INTO Author (aname)
VALUES ('J.K. Rowling');

INSERT 
INTO Writes (ISBN, aName)
VALUES ('9780736692427', 'George Orwell');

INSERT 
INTO Writes (ISBN, aName)
VALUES ('9780439708180', 'J.K. Rowling');

INSERT 
INTO  Ebook (price, fileSize, website, ISBN)
VALUES (20.00, 20, 'books.com/animalFarm', '9780736692427');

INSERT 
INTO User (uid, password, email)
VALUES ('mrhoda', 1234, 'mrhoda@yahoo.com');

INSERT 
INTO Store (sName, address)
VALUES ('Barnes &  Noble', '1345 Grove Street, Dallas, TX');

INSERT 
INTO PrintBook (price, newUsed, ISBN)
VALUES (11.38, 0, '9780736692427');

INSERT 
INTO PrintBook (price, newUsed, ISBN)
VALUES (7.00, 1, '9780439708180');

INSERT 
INTO Review (rating, comment, dateTime, ISBN, uid)
VALUES (4, 'It was decent.', '2016-09-19 10:20:00', '9780736692427', 'mrhoda');

INSERT 
INTO Sells (ISBN, uid)
VALUES ('9780736692427', 'mrhoda');

INSERT 
INTO Distributes (ISBN, address)
VALUES ('9780439708180', '1345 Grove Street, Dallas, TX');



