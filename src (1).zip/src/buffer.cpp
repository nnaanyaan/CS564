/** 
 *  @file    buffer.cpp
 *
 *  @author  Yan Nan - ID#: 9071924600
 *  @author  Laura Laidlaw - ID#: 9068449132
 *  @author  Midas Rhoda - ID#: 906813322
 *  @author  See Contributors.txt for code contributors and overview of BadgerDB
 *  
 *  @date    11/8/2016  
 *  @brief   CS 564 Project 3
 *
 *  @section DESCRIPTION
 *  
 *  This file is used to implement some of the functions (or methods) that the BufMgr Class 
 *  needs to effectively manage the buffer pool, buffer descriptions, and hashing of pages. This 
 *  assignments serves as a tool to conceptually understand the process in which databases are 
 *  mangaged and changed by means of a buffer pool consisting of frames made up of pages. Unlike 
 *  other buffer pools, this buffer is managed using the clock agorithm described in the 
 *  project3.pdf. 
 *  
 *  @section LICENSE
 *  Copyright (c) 2012 Database Group, Computer Sciences Department, University of Wisconsin-Madison
 *
 */

#include <memory>
#include <iostream>
#include "buffer.h"
#include "types.h"
#include "exceptions/buffer_exceeded_exception.h"
#include "exceptions/page_not_pinned_exception.h"
#include "exceptions/page_pinned_exception.h"
#include "exceptions/bad_buffer_exception.h"
#include "exceptions/hash_not_found_exception.h"
#include "exceptions/hash_already_present_exception.h"

namespace badgerdb { 

/** 
 *   @brief  Class constructor for BufMgr. Initializes the Buffer Manager with the correct number
 *   of frames corresponding structures for the hashTable, bufPool, hashTable, and bufDescTable.
 *  
 *   @param  bufs - is the number of frames in the buffer pool
 */ 
BufMgr::BufMgr(std::uint32_t bufs)
	: numBufs(bufs) {
	bufDescTable = new BufDesc[bufs];

  for (FrameId i = 0; i < bufs; i++) 
  {
  	bufDescTable[i].frameNo = i;
  	bufDescTable[i].valid = false;
  }

  bufPool = new Page[bufs];

	int htsize = ((((int) (bufs * 1.2))*2)/2)+1;
  hashTable = new BufHashTbl (htsize);  // allocate the buffer hash table

  clockHand = bufs - 1;
}

/** 
 *   @brief  Deallocate all resources relating to the buffer (buffer pool, BufDesc table, 
 *   and hashTable) and flushes out all dirty pages.
 */ 
BufMgr::~BufMgr() {

	// Loop over the buffer and flush out the dirty pages
	for (FrameId i = 0; i < numBufs; i++) {
		if (bufDescTable[i].valid && bufDescTable[i].dirty) {
			bufDescTable[i].file->writePage(bufPool[i]);
		}
	}
	// Deallocates the buffer pool, the BufDesc table and the hash table
	delete[] bufDescTable;
	delete[] bufPool;
	delete hashTable;
}

/** 
 *   @brief  Method which increments the clock to the next frame in the buffer 
 *   pool as described in project3.pdf
 *  
 *   @return void
 */ 
void BufMgr::advanceClock() {
	// Advance clock to next frame in the buffer pool
	// When it is not the last frame, just plus 1
	// When it is the the last frame, set it to 0
	if (clockHand == numBufs - 1) {
		clockHand = 0;
	} else {
		clockHand++;
	}
}

/** 
 *   @brief  Allocates a free frame based on the clock algorithm. To allocate a free frame,
 *   dirty pages may be written to the disk or if all frames are already pinned, then the method
 *   throws a BufferExceeded Exception. (called by readPage() and allocPage())
 *  
 *   @param  address of frame to be allocated
 *   @return void
 */ 
void BufMgr::allocBuf(FrameId & frame) {

	// Pointer to current BufDesc
	BufDesc* currBufDesc;
	// Count the pinned buffer
	std::uint32_t coutPinbuffer = 0;
	// Loop over the buffer untill find all the pinned buffer frames
	while (coutPinbuffer < numBufs) {
		// Advance the clockhand
		BufMgr::advanceClock();
		// Pointer to current BufDesc
		currBufDesc = &bufDescTable[clockHand];
		// If it is valid continue the Clock Replacement Algorithm
		if (currBufDesc->valid) {
			// If it is referenced recently, clear the refbit and restart the algorithm
			if (currBufDesc->refbit) {
				currBufDesc->refbit = false;
				continue;
			} else {
				// If it is not recently referenced, continue the algorithm
				if (currBufDesc->pinCnt > 0) {
					++coutPinbuffer;
					continue;
					// If it is not pinned, use current frame
				} else {
					// Remove corresponding entry from hashtable
					hashTable->remove(currBufDesc->file, currBufDesc->pageNo);
					// If current frame is dirty, writing a dirty page back to disk
					if (currBufDesc->dirty) {
						File* file = currBufDesc->file;
						file->writePage(bufPool[clockHand]);
					}
					break;
				}
			}
		} else {
			// If it is invalid, use the current fram
			break;
		}				
	}
	// Throws BufferExceededException if all buffer frames are pinned
	if (coutPinbuffer == numBufs) {
		throw BufferExceededException();
	}
	// Initialize BufDesc for current frame and use it
	currBufDesc->Clear();
	frame = clockHand;
}

/** 
 *   @brief  Method which determines whether it must read a page from the buffer pool or 
 *   move the data to the buffer pool from the disk to read the data of said page.
 *  
 *   @param  file is a pointer to the file in which the page to be read is located
 *   @param  pageNo page Number
 *   @param  page ptr which holds the address of the page to be read
 *   @return void
 */ 
void BufMgr::readPage(File* file, const PageId pageNo, Page*& page) {

	// Initialize the frame
	FrameId frame = 0;
	// Check whether the page is already in the buffer pool
	try {
		// find which frame the page is in
		hashTable->lookup(file, pageNo, frame);
		// set the appropriate refbit
		bufDescTable[frame].refbit = true;
		// increment the pinCnt for the page 
		++bufDescTable[frame].pinCnt;
		// return a pointer to the frame containing the page via the page parameter
		page = &bufPool[frame];
		
	} catch (HashNotFoundException e1) {
		
		// allocate a buffer frame
		BufMgr::allocBuf(frame);
		// read the page from disk into the buffer pool frame
		bufPool[frame] = file->readPage(pageNo);
		// insert the page into the hashtable
		hashTable->insert(file, pageNo, frame);
		// set up the page
		bufDescTable[frame].Set(file, pageNo);
		// return to a pointer to the buffer frame allocated for this page.
		page = &bufPool[frame];
		
	}
}

/** 
 *   @brief  Decrements the pin Count of the indicated frame (based on params)
 *   note if the frame is dirty then the dirty bit is set. 
 *   PageNotPinned is thrown if the pin count already has value 0. 
 *  
 *   @param  file is a pointer to the file in which the page to be read is located
 *   @param  pageNo page Number
 *   @param  dirty the dirty bit of the page (in the buffer)
 *   @return void
 */ 
void BufMgr::unPinPage(File* file, const PageId pageNo, const bool dirty) {

	// Initialize the frame
	FrameId frame = 0;
	// Check whether the page is already in the buffer pool
	try { // find which frame the page is in to check weather page can be found or not
		hashTable->lookup(file, pageNo, frame); 
		// if dirty == true, sets the dirty bit
		if (dirty) {
			bufDescTable[frame].dirty = true;
		}
		// Decrements the pinCnt of the frame containing (file, PageNo)
		// Throws PAGENOTPINNED if the pin count is already 0
		if (bufDescTable[frame].pinCnt == 0) {
			throw PageNotPinnedException(file->filename(), pageNo, frame);
		} else {
			--bufDescTable[frame].pinCnt;
		}
		
	} catch (HashNotFoundException e1) {
		
	}
}

/** 
 *   @brief  Method used to ge rid of all pages associated with a certain file from the 
 *   buffer pool. If the pages are dirty then they are written to the disk and then removed from the hashtable,
 *   buffer pool, and BufDesc table
 *  
 *   @param  file is a ptr to the file whose pages you wish to clear or "flush" from the buffer pool
 *   @return void
 */ 
void BufMgr::flushFile(const File* file) {

	// Loop over the buffer pool
	for (FrameId frame = 0; frame < numBufs; frame++) {
		// scan bufTable for pages belonging to the file
		if (bufDescTable[frame].file == file) {
		// Throws BadBufferException if an invalid page belonging to the file is encountered
			if (bufDescTable[frame].valid == false) {
				throw BadBufferException (
					frame, 
					bufDescTable[frame].dirty,
					bufDescTable[frame].valid,
					bufDescTable[frame].refbit
				);
			}
		// Throws PagePinnedException if some page of the file is pinned.
			if (bufDescTable[frame].pinCnt > 0) {
				throw PagePinnedException(file->filename(), bufDescTable[frame].pageNo, frame);
			}	
		// If the page is dirty
			if (bufDescTable[frame].dirty) {
				// flush the page to disk
				bufDescTable[frame].file->writePage(bufPool[frame]);
				// and set the dirty bit for the page to false 
				bufDescTable[frame].dirty = false;
			}
		// Remove the page from the hashtable
			hashTable->remove(file, bufPool[frame].page_number());
		// Clear the page frame of the BufDesc
			bufDescTable[frame].Clear();
		}
		
	}	
}

/** 
 *   @brief  Method used to obtain a buffer pool frame. In this method an empty page is 
 *   allocated in the respecive file and the entry is inserted into the hashtable. The page 
 *   number of the new page and the pointer to the buffer frame are returned indirectly through 
 *   the pageNo and page parameters.
 *  
 *   @param  file (where the page should be allocated)
 *   @param  pageNo address to the page number of hte newly made page
 *   @param  page ptr that points to address of the buffer frame where the page was allocated
 *   @return void
 */ 
void BufMgr::allocPage(File* file, PageId &pageNo, Page*& page) {
	// Initialize the frame
		FrameId frame = 0;
	// obtain a buffer pool frame
		BufMgr::allocBuf(frame);
	// allocate an empty page in the specified file
		bufPool[frame] = file->allocatePage();
	// obtain the page number of this page and return it
		pageNo = bufPool[frame].page_number();
	// insert an entry into hashtable for the page
		//hashTable->lookup(file,pageNo,lookupFrame);
		//if(lookupFrame != numBufs + 1) hashTable->remove(file, pageNo);
		try{
			hashTable->insert(file,pageNo,frame);
		} catch (HashAlreadyPresentException e2) {
			hashTable->remove(file, pageNo);
			hashTable->insert(file,pageNo,frame);
        	}
	
	// set up the page
		bufDescTable[frame].Set(file, pageNo);
	//  return the pointer to the buffer frame allocated for the page via the page parameter
		page = &bufPool[frame];
}

/** 
 *   @brief  Deletes a speciified page from a file, making sure that if the page is in
 *   the buffer pool, the frame where the page is should be freed and removed from the 
 *   hashtable (and bufDesc table).
 *  
 *   @param  file is a pointer to the file in where the page must be deleted
 *   @param  pageNo is the page number for the page that needs deleting
 *   @return void
 */ 
void BufMgr::disposePage(File* file, const PageId pageNo) {
	// Initialize the frame
		FrameId frame = 0;
	// Look up the page and get the frame number
		hashTable->lookup(file, pageNo, frame);
	// frame is freed and correspondingly entry from hash table is also removed
		hashTable->remove(file, pageNo);
		bufDescTable[frame].Clear();
		
	// delete the page from file
		file->deletePage(pageNo);
}

/** 
 *   @brief  Prints the contents of the Buffer Pool, specifically, the contents for each page in
 *   the bufDescTable
 *  
 *   @param  void
 *   @return void
 */ 
void BufMgr::printSelf(void) 
{
  BufDesc* tmpbuf;
	int validFrames = 0;
  
  for (std::uint32_t i = 0; i < numBufs; i++)
	{
  	tmpbuf = &(bufDescTable[i]);
		std::cout << "FrameNo:" << i << " ";
		tmpbuf->Print();

  	if (tmpbuf->valid == true)
    	validFrames++;
  }

	std::cout << "Total Number of Valid Frames:" << validFrames << "\n";
}

}

